# Panduan Setup GitHub Actions — Siap Pakai

## Isi paket ini
```
.github/
└── workflows/
    ├── ci.yml       # Lint + Test + Build (jalan di push & PR)
    └── deploy.yml   # Deploy otomatis ke VPS via SSH (jalan di merge main)
```

## Langkah-langkah pemasangan

### 1. Salin ke repo kamu
Salin folder `.github/` ini ke root repository GitHub kamu, lalu commit & push.

### 2. Sesuaikan dengan stack kamu
- **Node.js/React/Next.js**: file ini langsung jalan. Pastikan di `package.json` ada script: `lint`, `test`, `build`.
- **Stack lain (Laravel, Python, Go, dll)**: minta saya untuk menyesuaikan — tinggal sebutkan stack-nya.

### 3. Buat Secrets di GitHub (wajib untuk deploy)
Buka repo kamu → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**, lalu buat:

| Nama Secret | Isi |
|---|---|
| `SSH_HOST` | Alamat IP / domain server VPS |
| `SSH_USER` | Username login server (misal `root` atau `deploy`) |
| `SSH_PORT` | Port SSH (biasanya `22`) |
| `SSH_PRIVATE_KEY` | Isi file private key (cat ~/.ssh/id_ed25519) |
| `DEPLOY_PATH` | Folder aplikasi di server (misal `/var/www/myapp`) |
| `NEXT_PUBLIC_API_URL` (opsional) | URL API untuk build-time |

### 4. Persiapan di server VPS
- Buat user khusus deploy (disarankan, jangan pakai root):
  ```bash
  sudo adduser deploy
  sudo usermod -aG www-data deploy
  ```
- Pasang public key di server: tempel isi `id_ed25519.pub` ke `/home/deploy/.ssh/authorized_keys`
- Install PM2 (untuk Node.js): `npm i -g pm2` — atau siapkan service `systemd`.

### 5. Cek hasilnya
Buka tab **Actions** di repo GitHub kamu. Setiap push/PR akan memicu workflow `CI`, dan setiap merge ke `main` akan memicu `Deploy`.

## Tips agar lancar (dibantu AI)
1. **Jika gagal**: klik job yang merah → salin log error → tempel ke AI untuk diagnosa.
2. **Optimasi waktu**: jika build lama, minta AI tambahkan cache atau split job.
3. **Validasi YAML**: sebelum push, minta AI cek indentasi & syntax (satu spasi salah = workflow gagal).
4. **Security review**: minta AI periksa apakah ada secret yang tidak sengaja terekspos.

## Butuh penyesuaian?
Sebutkan:
- Stack teknologi (Laravel? Django? Go? Flutter? Spring Boot?)
- Target deploy (VPS? Vercel? Netlify? AWS EC2/S3? Docker?)
- Yang mau diotomatisasi (test saja? release? notifikasi Telegram/WhatsApp?)

Saya akan sesuaikan file workflow-nya.
